// 15. Build a simple HTTP server that serves different routes. Implement middleware using the
// http.Handler interface to add logging or authentication functionality to specific routes, showcasing
// the power of middleware in web applications.

package main

import (
	"fmt"
	"log"
	"net/http"
)

// Define a middleware function that logs information about each incoming
// request.
func loggingMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		log.Printf("Received request: %s %s", r.Method, r.URL)
		next.ServeHTTP(w, r)
	})
}

// Define a middleware function that authenticates users.
func authenticationMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// TODO: Implement authentication logic here.
		// If the user is authenticated, call the next handler.
		next.ServeHTTP(w, r)
	})
}

// Define a handler function for the root route.
func rootHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Hello, World!")
}

// Define a handler function for the /protected route.
func protectedHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "This is a protected route.")
}
func main() {
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		loggingMiddleware(http.HandlerFunc(rootHandler)).ServeHTTP(w, r)
	})
	http.HandleFunc("/protected", func(w http.ResponseWriter, r *http.Request) {
		authenticationMiddleware(http.HandlerFunc(protectedHandler)).ServeHTTP(w, r)
	})
	// Start the server.
	log.Fatal(http.ListenAndServe(":8080", nil))
}
