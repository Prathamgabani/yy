// 16. Create a program that performs file operations like reading and writing. Implement custom error
// types for scenarios such as file not found or permission denied. Use type assertions to discriminate
// between error types and provide appropriate error handling.

package main

import (
	"fmt"
	"io/ioutil"
	"os"
)

// FileNotFoundError represents an error when a file is not found
type FileNotFoundError struct {
	FileName string
}

func (e FileNotFoundError) Error() string {
	return fmt.Sprintf("file '%s' not found", e.FileName)
}

// PermissionDeniedError represents an error when permission is denied for
type PermissionDeniedError struct {
	FileName string
}

func (e PermissionDeniedError) Error() string {
	return fmt.Sprintf("permission denied for file '%s'", e.FileName)
}
func readFile(filename string) ([]byte, error) {
	content, err := ioutil.ReadFile(filename)
	if os.IsNotExist(err) {
		return nil, FileNotFoundError{FileName: filename}
	} else if os.IsPermission(err) {
		return nil, PermissionDeniedError{FileName: filename}
	}
	return content, nil
}
func main() {
	filename := "pratham.txt"
	content, err := readFile(filename)
	if err != nil {
		switch e := err.(type) {
		case FileNotFoundError:
			fmt.Println("Error:", e)
		case PermissionDeniedError:
			fmt.Println("Error:", e)
		default:
			fmt.Println("Error:", err)
		}
		return
	}
	fmt.Println("Content of", filename+":")
	fmt.Println(string(content))
}
