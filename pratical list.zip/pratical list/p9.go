// 9. Develop a program that simulates a bank account. Use a struct to represent the account, and
// implement methods for depositing, withdrawing, and checking the account balance.

package main

import (
	"fmt"
	"os"
)

type BankAccount struct {
	balance int
}

func (account *BankAccount) Deposit(amount int) {
	account.balance += amount
}
func (account *BankAccount) Withdraw(amount int) error {
	if amount > account.balance {
		return fmt.Errorf("Insufficient balance")
	}
	account.balance -= amount
	return nil
}
func (account BankAccount) GetBalance() int {
	return account.balance
}
func main() {
	account := BankAccount{balance: 1000}
	for {
		fmt.Println("\nBank Account Menu")
		fmt.Println("================")
		fmt.Println("1. Deposit")
		fmt.Println("2. Withdraw")
		fmt.Println("3. Check Balance")
		fmt.Println("4. Quit")
		var choice int
		fmt.Print("Enter your choice: ")
		_, err := fmt.Scanf("%d\n", &choice)
		if err != nil {
			fmt.Println("Error reading input:", err)
			return
		}
		var amount int
		switch choice {
		case 1:
			fmt.Print("Enter the deposit amount: ")
			_, err = fmt.Scanf("%d\n", &amount)
			if err != nil {
				fmt.Println("Error reading input:", err)
				return
			}
			account.Deposit(amount)
			fmt.Println("Deposit successful!")
		case 2:
			fmt.Print("Enter the withdrawal amount: ")
			_, err = fmt.Scanf("%d\n", &amount)
			if err != nil {
				fmt.Println("Error reading input:", err)
				return
			}
			err := account.Withdraw(amount)
			if err != nil {
				fmt.Println("Withdrawal failed:", err)
			} else {
				fmt.Println("Withdrawal successful!")
			}
		case 3:
			fmt.Println("Current balance:", account.GetBalance())
		case 4:
			fmt.Println("Exiting...")
			os.Exit(0)
		default:
			fmt.Println("Invalid choice. Please enter a number between 1 and 4.")
		}
	}
}
