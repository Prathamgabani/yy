// 6. Design a program that models a library system. Use structs to represent books with attributes like
// title, author, and publication year. Implement functions to check out and return books.

package main

import (
	"fmt"
)

type Book struct {
	Title           string
	Author          string
	PublicationYear int
}

func (b *Book) CheckOut() {
	fmt.Println(fmt.Sprintf("Book %s by %s checked out.", b.Title, b.Author))
}
func (b *Book) Return() {
	fmt.Println(fmt.Sprintf("Book %s by %s returned.", b.Title, b.Author))
}
func main() {
	book := Book{
		Title:           "The Go Programming Language",
		Author:          "Alan A. A. Donovan",
		PublicationYear: 2015,
	}
	book.CheckOut()
	book.Return()
}
