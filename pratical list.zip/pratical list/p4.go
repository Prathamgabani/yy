// 4. Develop a program that manages a to-do list. Allow users to add, remove, and display tasks using
// slices. Demonstrate the flexibility of slices in handling dynamic data.

package main

import (
	"fmt"
)

func main() {
	var todoList []string
	for {
		fmt.Println("\nTodo List Management")
		fmt.Println("1. Add Task")
		fmt.Println("2. Remove Task")
		fmt.Println("3. Display Tasks")
		fmt.Println("4. Exit")
		fmt.Print("Enter your choice: ")
		var choice int
		_, err := fmt.Scanln(&choice)
		if err != nil {
			fmt.Println("Invalid input. Please enter a number.")
			continue
		}
		switch choice {
		case 1:
			addTask(&todoList)
		case 2:
			removeTask(&todoList)
		case 3:
			displayTasks(todoList)
		case 4:
			fmt.Println("Exiting program.")
			return
		default:
			fmt.Println("Invalid choice. Please enter a number between 1 and 4.")
		}
	}
}
func addTask(todoList *[]string) {
	var task string
	fmt.Print("Enter task to add: ")
	fmt.Scanln(&task)
	*todoList = append(*todoList, task)
	fmt.Println("Task added successfully!")
}
func removeTask(todoList *[]string) {
	var index int
	fmt.Print("Enter index of task to remove: ")
	_, err := fmt.Scanln(&index)
	if err != nil || index < 0 || index >= len(*todoList) {
		fmt.Println("Invalid index.")
		return
	}
	*todoList = append((*todoList)[:index], (*todoList)[index+1:]...)
	fmt.Println("Task removed successfully!")
}
func displayTasks(todoList []string) {
	if len(todoList) == 0 {
		fmt.Println("Todo list is empty.")
		return
	}
	fmt.Println("Current tasks:")
	for i, task := range todoList {
		fmt.Printf("%d. %s\n", i+1, task)
	}
}
