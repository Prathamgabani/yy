// 5 . Build a simple dictionary program where users can look up word definitions. Utilize a map to store
// word-definition pairs and implement operations like adding new words and looking up definitions.

package main

import (
	"fmt"
)

type Dictionary map[string]string

func main() {
	dictionary := make(Dictionary)
	for {
		fmt.Println("\nDictionary Menu:")
		fmt.Println("1. Add a new word")
		fmt.Println("2. Look up a word")
		fmt.Println("3. Exit")
		var choice int
		fmt.Scanf("%d", &choice)
		switch choice {
		case 1:
			addWord(&dictionary)
		case 2:
			lookupWord(dictionary)
		case 3:
			fmt.Println("Exiting...")
			return
		default:
			fmt.Println("Invalid choice. Please try again.")
		}
	}
}
func addWord(dictionary *Dictionary) {
	var word, definition string
	fmt.Println("Enter the word: ")
	fmt.Scanf("%s", &word)
	fmt.Println("Enter the definition: ")
	fmt.Scanf("%s", &definition)
	(*dictionary)[word] = definition
	fmt.Println("Word added successfully.")
}
func lookupWord(dictionary Dictionary) {
	var word string
	fmt.Println("Enter the word to look up: ")
	fmt.Scanf("%s", &word)
	definition, ok := dictionary[word]
	if ok {
		fmt.Printf("Definition: %s\n", definition)
	} else {
		fmt.Println("Word not found in the dictionary.")
	}
}
