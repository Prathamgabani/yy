// 11. Build a geometry calculator that computes the area and perimeter of various shapes. Define an
// interface Shape with methods like Area() and Perimeter(). Implement this interface for shapes such
// as rectangles, circles, and triangles, showcasing interface contracts

package main

import (
	"fmt"
	"math"
)

// Shape is an interface for geometric shapes
type Shape interface {
	Area() float64
	Perimeter() float64
}

// Rectangle represents a rectangle
type Rectangle struct {
	Width  float64
	Height float64
}

// Area calculates the area of a rectangle
func (r Rectangle) Area() float64 {
	return r.Width * r.Height
}

// Perimeter calculates the perimeter of a rectangle
func (r Rectangle) Perimeter() float64 {
	return 2*r.Width + 2*r.Height
}

// Circle represents a circle
type Circle struct {
	Radius float64
}

// Area calculates the area of a circle
func (c Circle) Area() float64 {
	return math.Pi * c.Radius * c.Radius
}

// Perimeter calculates the perimeter of a circle (circumference)
func (c Circle) Perimeter() float64 {
	return 2 * math.Pi * c.Radius
}

// Triangle represents a triangle
type Triangle struct {
	SideA float64
	SideB float64
	SideC float64
}

// Area calculates the area of a triangle using Heron's formula
func (t Triangle) Area() float64 {
	s := (t.SideA + t.SideB + t.SideC) / 2
	return math.Sqrt(s * (s - t.SideA) * (s - t.SideB) * (s - t.SideC))
}

// Perimeter calculates the perimeter of a triangle
func (t Triangle) Perimeter() float64 {
	return t.SideA + t.SideB + t.SideC
}
func main() {
	rectangle := Rectangle{Width: 5, Height: 3}
	printShapeInfo("Rectangle", rectangle)
	// Circle
	circle := Circle{Radius: 4}
	printShapeInfo("Circle", circle)
	// Triangle
	triangle := Triangle{SideA: 3, SideB: 4, SideC: 5}
	printShapeInfo("Triangle", triangle)
}
func printShapeInfo(shapeName string, shape Shape) {
	fmt.Printf("%s:\n", shapeName)
	fmt.Printf("Area: %.2f\n", shape.Area())
	fmt.Printf("Perimeter: %.2f\n", shape.Perimeter())
	fmt.Println()
}
