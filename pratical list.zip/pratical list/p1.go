// 1 . Write a Go program that reads user input, performs a simple calculation (e.g., addition or
// 	multiplication), and outputs the result. Focus on organizing the code into functions and using proper
// 	program structure.

package main

import (
	"fmt"
	"strconv"
)

// GetInput prompts the user for input and returns the parsed integer value.
func GetInput(message string) (int, error) {
	fmt.Println(message)
	var input string
	_, err := fmt.Scanln(&input)
	if err != nil {
		return 0, err
	}
	return strconv.Atoi(input)
}

// ChooseOperation presents the user with options and returns the chosen

func ChooseOperation() string {
	fmt.Println("Choose an operation:")
	fmt.Println("1. Addition")
	fmt.Println("2. Multiplication")
	var choice string
	_, err := fmt.Scanln(&choice)
	if err != nil {
		panic(err) // Handle error more gracefully in a production environment
	}
	return choice
}

// PerformCalculation takes two numbers and an operation, performs the

func PerformCalculation(num1 int, num2 int, operation string) (int, error) {
	switch operation {
	case "1":
		return num1 + num2, nil
	case "2":
		return num1 * num2, nil
	default:
		return 0, fmt.Errorf("Invalid operation: %s", operation)
	}
}
func main() {
	num1, err := GetInput("Enter the first number:")
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	num2, err := GetInput("Enter the second number:")
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	operation := ChooseOperation()
	result, err := PerformCalculation(num1, num2, operation)
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	fmt.Printf("The result is: %d\n", result)
}
