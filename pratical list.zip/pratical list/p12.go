// 12 . Create a command-line tool for handling configuration parameters with custom flags. Use the
// flag package and implement a custom flag type that satisfies the flag.Value interface for parsing
// complex configuration settings.

package main

import (
	"flag"
	"fmt"
	"strings"
)

// CustomFlag represents a custom flag type that satisfies the flag.Value interface
type CustomFlag struct {
	Value string
}

// String returns the string representation of the CustomFlag value
func (c *CustomFlag) String() string {
	return c.Value
}

// Set sets the value of the CustomFlag
func (c *CustomFlag) Set(value string) error {
	c.Value = value
	return nil
}
func main() {
	var config CustomFlag
	flag.Var(&config, "config", "Specify configuration parameters in the format key1=value1,key2=value2,...")
	flag.Parse()
	params := strings.Split(config.Value, ",")
	fmt.Println("Configuration Parameters:")
	for _, param := range params {
		pair := strings.SplitN(param, "=", 2)
		if len(pair) != 2 {
			fmt.Printf("Invalid parameter format: %s\n", param)
			continue
		}
		key, value := pair[0], pair[1]
		fmt.Printf("%s: %s\n", key, value)
	}
}
