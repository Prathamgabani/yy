// 8. Write a program that calculates the factorial of a given number. Use a function for the
// calculation
// and provide options for users to input different numbers to find their factorials in go.

package main

import (
	"fmt"
)

// factorial calculates the factorial of n
func factorial(n int) int {
	if n == 0 {
		return 1
	}
	result := 1
	for i := 1; i <= n; i++ {
		result *= i
	}
	return result
}
func main() {
	var num int
	for {
		fmt.Print("Enter a number to calculate factorial (negative number to exit): ")
		fmt.Scanln(&num)
		if num < 0 {
			fmt.Println("Exiting program.")
			return
		}
		fmt.Printf("Factorial of %d is: %d\n", num, factorial(num))
	}
}
