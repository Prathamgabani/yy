// 2. Create a program that converts temperatures between Fahrenheit and Celsius. Use variables to
// store temperature values and ensure proper data type conversions during calculations.

package main

import (
	"fmt"
)

func main() {
	var fahrenheit, celsius float64
	// Get temperature in Fahrenheit from user
	fmt.Print("Enter temperature in Fahrenheit: ")
	fmt.Scanln(&fahrenheit)
	// Convert Fahrenheit to Celsius
	celsius = (fahrenheit - 32) * 5 / 9
	// Output the result
	fmt.Printf("%.2f°F is equal to %.2f°C\n", fahrenheit, celsius)
	// Convert Celsius back to Fahrenheit
	fahrenheit = celsius*9/5 + 32
	// Output the result
	fmt.Printf("%.2f°C is equal to %.2f°F\n", celsius, fahrenheit)
}
