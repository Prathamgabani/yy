//10 .Extend the bank account program from the previous example to handle errors.Implement error
// checks for scenarios like insufficient funds during withdrawals or invalid inputs during deposits in go.

package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
)

// BankAccount struct represents a bank account with a balance attribute
type BankAccount struct {
	Balance int
}

// Deposit method to deposit an amount into the bank account
func (account *BankAccount) Deposit(amount string) error {
	depositAmount, err := strconv.Atoi(amount)
	if err != nil {
		return fmt.Errorf("invalid deposit amount: %w", err)
	}
	if depositAmount <= 0 {
		return fmt.Errorf("deposit amount must be positive")
	}
	account.Balance += depositAmount
	return nil
}

// Withdraw method to withdraw an amount from the bank account
func (account *BankAccount) Withdraw(amount int) error {
	if amount <= 0 {
		return fmt.Errorf("withdrawal amount must be positive")
	}
	if amount > account.Balance {
		return fmt.Errorf("insufficient balance")
	}
	account.Balance -= amount
	return nil
}

// GetBalance method to check the current balance of the bank account
func (account BankAccount) GetBalance() int {
	return account.Balance
}
func main() {
	account := BankAccount{Balance: 1000}
	scanner := bufio.NewScanner(os.Stdin)
	for {
		fmt.Println("\nBank Account Menu")
		fmt.Println("================")
		fmt.Println("1. Deposit")
		fmt.Println("2. Withdraw")
		fmt.Println("3. Check Balance")
		fmt.Println("4. Quit")
		var choice int
		fmt.Print("Enter your choice: ")
		_, inputErr := fmt.Scanf("%d\n", &choice)
		if inputErr != nil {
			fmt.Println("Error reading input:", inputErr)
			return
		}
		var amount int
		var err error
		switch choice {
		case 1:
			fmt.Print("Enter the deposit amount: ")
			scanner.Scan()
			depositAmount := scanner.Text()
			err = account.Deposit(depositAmount)
			if err != nil {
				fmt.Println("Error depositing amount:", err)
				continue
			}
			fmt.Println("Deposit successful!")
		case 2:
			fmt.Print("Enter the withdrawal amount: ")
			scanner.Scan()
			withdrawalAmtStr := scanner.Text()
			amount, err = strconv.Atoi(withdrawalAmtStr)
			if err != nil {
				fmt.Println("Error converting input:", err)
				continue
			}
			err = account.Withdraw(amount)
			if err != nil {
				fmt.Println("Error withdrawing amount:", err)
				continue
			}
			fmt.Println("Withdrawal successful!")
		case 3:
			fmt.Printf("Current balance: %d\n", account.GetBalance())
		case 4:
			fmt.Println("Goodbye!")
			return
		default:
			fmt.Println("Invalid choice. Please try again.")
		}
	}
}
