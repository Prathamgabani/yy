// 3. Implement a program that calculates the average of a set of exam scores using an array. Allow the
// user to input the scores and use an array to store and process the data

package main

import (
	"fmt"
)

func main() {
	var numScores int
	// Prompt user for the number of scores
	fmt.Print("Enter the number of exam scores: ")
	fmt.Scanln(&numScores)
	// Create an array to store the scores
	scores := make([]float64, numScores)
	// Input exam scores from the user
	for i := 0; i < numScores; i++ {
		fmt.Printf("Enter score %d: ", i+1)
		fmt.Scanln(&scores[i])
	}
	// Calculate the sum of scores
	sum := 0.0
	for _, score := range scores {
		sum += score
	}
	// Calculate the average score
	average := sum / float64(numScores)
	// Output the average score
	fmt.Printf("Average score: %.2f\n", average)
}
