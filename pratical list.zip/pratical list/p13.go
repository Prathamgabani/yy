// 13 Develop a generic container that can hold and operate on values of different types using
// interfaces. Allow users to add, retrieve, and perform operations on elements stored in the container,
// highlighting the flexibility of interface values.

package main

import (
	"fmt"
)

// Container is a generic container that can hold elements of any type
type Container struct {
	data []interface{}
}

// Add adds an element to the container
func (c *Container) Add(element interface{}) {
	c.data = append(c.data, element)
}

// Get retrieves an element from the container at the specified index
func (c *Container) Get(index int) interface{} {
	if index < 0 || index >= len(c.data) {
		return nil
	}
	return c.data[index]
}

// Len returns the number of elements in the container
func (c *Container) Len() int {
	return len(c.data)
}
func main() {
	// Create a container
	container := Container{}
	// Add elements of different types to the container
	container.Add(10)
	container.Add("Hello")
	container.Add(3.14)
	// Retrieve and print elements from the container
	for i := 0; i < container.Len(); i++ {
		fmt.Printf("Element at index %d: %v\n", i, container.Get(i))
	}
}
