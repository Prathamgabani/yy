// 14. Design a program that manages a collection of custom objects and requires sorting based on
// multiple criteria. Implement the sort.Interface for custom sorting, allowing users to sort the
// collection dynamically according to different attributes.

package main

import (
	"fmt"
	"sort"
)

// Person represents a person with name, age, and height attributes
type Person struct {
	Name   string
	Age    int
	Height float64
}

// People represents a collection of Person objects
type People []Person

// Len returns the length of the People slice
func (p People) Len() int { return len(p) }

// Less compares two Person objects based on name, then age, then height
func (p People) Less(i, j int) bool {
	if p[i].Name != p[j].Name {
		return p[i].Name < p[j].Name
	}
	if p[i].Age != p[j].Age {
		return p[i].Age < p[j].Age
	}
	return p[i].Height < p[j].Height
}

// Swap swaps two Person objects in the People slice
func (p People) Swap(i, j int) { p[i], p[j] = p[j], p[i] }
func main() {
	// Define a collection of people
	people := People{
		{"John", 30, 175.5},
		{"Alice", 25, 160.0},
		{"John", 25, 170.0},
		{"Bob", 35, 180.0},
		{"Alice", 25, 165.0},
	}
	// Print the unsorted collection
	fmt.Println("Unsorted:")
	for _, person := range people {
		fmt.Printf("%-6s %-3d %.1f\n", person.Name, person.Age, person.Height)
	}
	// Sort the collection
	sort.Sort(people)
	// Print the sorted collection
	fmt.Println("\nSorted:")
	for _, person := range people {
		fmt.Printf("%-6s %-3d %.1f\n", person.Name, person.Age, person.Height)
	}
}
